package W;

import W.Board;
import W.Cell;
import W.Player;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Gui {

    static int a = -1;
    static int b = -1;
    static int c = -1;
    static int d = -1;

    static boolean bringPiece = false;
    static Player p = null;
    static JButton jw = null;
    public static void Graphic_move (Board B){

        for (int i = 0; i < B.getGame_state().getButtons().size(); i++) {

            JButton s = B.getGame_state().getButtons().get(i);

            if (Integer.parseInt(s.getName()) < 100) {
                s.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        boolean w = true;


                        if (Board.Button_isSelected == false) {


                            Board.Button_isSelected = true;

                            s.setBackground(java.awt.Color.cyan);


                            a = Integer.parseInt(B.getGame_state().setSimple(s).charAt(0) + "");
                            b = Integer.parseInt(B.getGame_state().setSimple(s).charAt(1) + "");

                            w = false;

                        }

                        if (!bringPiece && w && Board.Button_isSelected) {
                            B.getGame_state().findBtn(a, b).setBackground(new java.awt.Color(255, 160, 122));
                            c = Integer.parseInt(B.getGame_state().setSimple(s).charAt(0) + "");
                            d = Integer.parseInt(B.getGame_state().setSimple(s).charAt(1) + "");

                            if (a >= 0 && b >= 0 && a <= 4 && b <= 4 && c >= 0 && d >= 0 && c <= 4 && d <= 4) {
                                B.Move(B.getPieces()[a][b], new Cell(a, b, B), new Cell(c, d, B));


                            }


                            Board.Button_isSelected = false;
                        }

                        if (bringPiece && w && Board.Button_isSelected) {
                            jw.setBackground(new Color(240, 230, 140));
                            c = Integer.parseInt(B.getGame_state().setSimple(s).charAt(0) + "");
                            d = Integer.parseInt(B.getGame_state().setSimple(s).charAt(1) + "");

                            bringPiece = false;
                            if (c >= 0 && d >= 0 && c <= 4 && d <= 4) {

                                if (p.Player_turn()) {
                                    B.BringNewPiece(jw.getText(), p, new Cell(c, d, B));

                                    if (Board.done) {
                                        jw.setText("")
                                        ;
                                        jw.setIcon(null);
                                        Board.done = false;
                                    }
                                }

                            }


                            Board.Button_isSelected = false;
                        }
                        B.Create_graphic();
                        B.show_piece();

                    }
                });
            }

            if (Integer.parseInt(s.getName()) <= 5155 && Integer.parseInt(s.getName()) >= 5150) {


                s.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        boolean w = true;


                        if (Board.Button_isSelected == false) {


                            bringPiece = true;
                            Board.Button_isSelected = true;

                            jw = s;
                            p = B.getPlayerW();

                            s.setBackground(java.awt.Color.cyan);


                            a = Integer.parseInt(B.getGame_state().setSimple(s).charAt(0) + "");
                            b = Integer.parseInt(B.getGame_state().setSimple(s).charAt(1) + "");

                            w = false;

                        }


                    }
                });
            }
            if (Integer.parseInt(s.getName()) <= 5165 && Integer.parseInt(s.getName()) >= 5160) {


                s.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        boolean w = true;


                        if (Board.Button_isSelected == false) {


                            bringPiece = true;
                            Board.Button_isSelected = true;

                            jw = s;
                            p = B.getPlayerB();

                            s.setBackground(java.awt.Color.cyan);


                            a = Integer.parseInt(B.getGame_state().setSimple(s).charAt(0) + "");
                            b = Integer.parseInt(B.getGame_state().setSimple(s).charAt(1) + "");

                            w = false;

                        }


                    }
                });
            }
        }

    }
    public static void main(String[] args) {

            Board B = new Board();
            B.Create_Board();
            B.Create_graphic();

            B.show_piece();
            Graphic_move(B);
            B.graphic_deleted_pieces();


    }
}
