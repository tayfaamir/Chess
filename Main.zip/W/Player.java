package W;

import java.util.LinkedList;


public class Player {

    static int turn=0;

    private Color color;
    private LinkedList<Piece> pieces=new LinkedList<>();
    private boolean King_dead;
    private boolean player_turn;

    public Player(Color color) {


        this.color = color;

        King_dead=false;

        this.player_turn =false;

    }


    public void setPlayer_turn(boolean player_turn) {
        this.player_turn = player_turn;
    }

    public boolean isKing_dead() {
        return King_dead;
    }

    public void setKing_dead(boolean king_dead) {
        King_dead = king_dead;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public LinkedList<Piece> getPieces() {
        return pieces;
    }

    public void setPieces(LinkedList<Piece> pieces) {
        this.pieces = pieces;
    }

    public boolean Player_turn(){

        if(this.getColor().equals(Color.WHITE)&&Player.turn%2==1){
            return true;
        }
        if(this.getColor().equals(Color.BLACK)&&Player.turn%2==0){
            return true;
        }
        return false;
    }
    public void Change(){

        for (int i = 0; i < this.getPieces().size(); i++) {

            pieces.get(i).setColor(this.getColor());
            pieces.get(i).setPlayer(this);

        }
    }

}
