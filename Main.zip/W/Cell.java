package W;

import java.awt.*;

public class Cell {


    private  int x, y;
    private Piece piece;
    private Board board;

    public Cell(int x, int y,Board board) {
        this.x = x;
        this.y = y;

        this.piece=board.getPieces()[x][y];
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Piece getPiece() {
        return piece;
    }

    public void setPiece(Piece piece) {
        this.piece = piece;
    }


}
