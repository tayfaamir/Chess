package W;

import java.awt.*;

public class King extends Piece {


    public King(Cell currentCell, Color color,Board board) {
        super(currentCell,color,board);
    }

    public boolean is_Valid_move(Cell cell) {
        if (cell.getPiece() == null) {
            if (cell.getX() == this.getCurrentCell().getX() + 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                return true;
            }
            if (cell.getX() == this.getCurrentCell().getX() && (this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                return true;
            }
            if (cell.getX() == this.getCurrentCell().getX() - 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                return true;
            }
            return false;
        } else {
            if (!cell.getPiece().getColor().equals(this.getColor())) {
                if (cell.getX() == this.getCurrentCell().getX() + 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }
                if (cell.getX() == this.getCurrentCell().getX() && (this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }
                if (cell.getX() == this.getCurrentCell().getX() - 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }
                return false;

            }
            return false;
        }
    }
    @Override
    public String toString() {
        if(this.getColor().equals(Color.WHITE)){
            return "K";
        }
        else return "k";
    }
}
