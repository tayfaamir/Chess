

import W.Board;
import W.Cell;


import java.awt.*;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Board B = new Board();
        B.Create_Board();




        while (B.getPlayerW().isKing_dead() == false && B.getPlayerB().isKing_dead() == false) {


            String po = scanner.nextLine() ;

            if (po.equals("0")) {
                break;

            }
            Scanner scanner1 = new Scanner(po);
            String p = scanner1.next();
            String N1 = scanner1.next();
            String N2 = scanner1.next();

            int b = Integer.parseInt(N1.charAt(0) + "") - 1;
            int a = Integer.parseInt(N1.charAt(1) + "") - 1;

            int d = Integer.parseInt(N2.charAt(0) + "") - 1;
            int c = Integer.parseInt(N2.charAt(1) + "") - 1;

            if (a >= 0 && b >= 0 && a <= 4 && b <= 4 && c >= 0 && d >= 0 && c <= 4 && d <= 4) {
                Cell cell2 = new Cell(a, b, B);
                Cell cell3 = new Cell(c, d, B);
                if (B.getPieces()[a][b] != null) {

                }
                if (B.getPieces()[a][b] != null && B.getPieces()[a][b].toString().equals(p)) {

                    B.Move(B.getPieces()[a][b], cell2, cell3);

                }
            }
            if ((a == -1 && b == -1 && c >= 0 && d >= 0 && c <= 4 && d <= 4)) {
                Cell cell2 = new Cell(c, d, B);
                if (Character.isUpperCase(p.charAt(0))) {
                    B.BringNewPiece(p, B.getPlayerW(), cell2);

                }
                if (Character.isLowerCase(p.charAt(0))) {
                    B.BringNewPiece(p, B.getPlayerB(), cell2);

                }

            }

            String w = "";
            if (B.getPlayerW().getPieces().size() != 0) {
                for (int i = 0; i < B.getPlayerW().getPieces().size(); i++) {
                    w = w + B.getPlayerW().getPieces().get(i);
                }
            }
                String bb = "";
                if (B.getPlayerB().getPieces().size() != 0) {
                    for (int i = 0; i < B.getPlayerB().getPieces().size(); i++) {
                        bb = bb + B.getPlayerB().getPieces().get(i);
                    }
                }


            System.out.println(B);
            System.out.println(bb);
            System.out.println(w);



//        k 55 44
//        L 15 45
//        k 44 45
//        P 00 33
//        l 00 34


        }

        if(B.getPlayerW().isKing_dead()){
            System.out.println("white wins!");
        }
        if(B.getPlayerB().isKing_dead()){
            System.out.println("black wins!");
        }
    }

}