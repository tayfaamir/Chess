package W;
import java.util.Arrays;
import java.util.LinkedList;

public class Board {


    private Player player;
    private Piece piece;
    private Cell cell;
    private Piece[][]pieces=new Piece[5][5];

    private Player playerW=new Player(Color.WHITE);
    private Player playerB=new Player(Color.BLACK);

    public Board() {


    }

    public Player getPlayerW() {
        return playerW;
    }

    public void setPlayerW(Player playerW) {
        this.playerW = playerW;
    }

    public Player getPlayerB() {
        return playerB;
    }

    public void setPlayerB(Player playerB) {
        this.playerB = playerB;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Piece getPiece() {
        return piece;
    }

    public void setPiece(Piece piece) {
        this.piece = piece;
    }

    public Cell getCell() {
        return cell;
    }

    public void setCell(Cell cell) {
        this.cell = cell;
    }

    public Piece[][] getPieces() {
        return pieces;
    }

    public void setPieces(Piece[][] pieces) {
        this.pieces = pieces;
    }

    public void Create_Board(){
        Cell cell=new Cell(0,0,this);
        Piece piece=new King(cell,Color.WHITE,this);
        this.getPieces()[0][0]=piece;
        Cell cell1=new Cell(0,1,this);
        Piece piece1=new GoldGeneral(cell1,Color.WHITE,this);
        this.getPieces()[0][1]=piece1;

        Cell cell2=new Cell(0,2,this);
        Piece piece2=new SilverGeneral(cell2,Color.WHITE,this);
        this.getPieces()[0][2]=piece2;
        Cell cell3=new Cell(0,3,this);
        Piece piece3=new Bishop(cell3,Color.WHITE,this);
        this.getPieces()[0][3]=piece3;
        Cell cell4=new Cell(0,4,this);
        Piece piece4=new Lance(cell4,Color.WHITE,this);
        this.getPieces()[0][4]=piece4;
        Cell cell5=new Cell(1,0,this);
        Piece piece5=new Pawn(cell5,Color.WHITE,this);
        this.getPieces()[1][0]=piece5;
        piece.setPlayer(this.getPlayerW());piece1.setPlayer(this.getPlayerW());piece2.setPlayer(this.getPlayerW());piece3.setPlayer(this.getPlayerW());piece4.setPlayer(this.getPlayerW());piece5.setPlayer(this.getPlayerW());
        Cell cell01=new Cell(4,0,this);
        Piece piece01=new Lance(cell01,Color.BLACK,this);
        this.getPieces()[4][0]=piece01;
        Cell cell02=new Cell(4,1,this);
        Piece piece02=new Bishop(cell02,Color.BLACK,this);
        this.getPieces()[4][1]=piece02;
        Cell cell03=new Cell(4,2,this);
        Piece piece03=new SilverGeneral(cell03,Color.BLACK,this);
        this.getPieces()[4][2]=piece03;
        Cell cell04=new Cell(4,3,this);
        Piece piece04=new GoldGeneral(cell04,Color.BLACK,this);
        this.getPieces()[4][3]=piece04;
        Cell cell05=new Cell(4,4,this);
        Piece piece05=new King(cell05,Color.BLACK,this);
        this.getPieces()[4][4]=piece05;
        Cell cell06=new Cell(3,4,this);
        Piece piece06=new Pawn(cell06,Color.BLACK,this);
        this.getPieces()[3][4]=piece06;
        piece01.setPlayer(this.getPlayerB());piece02.setPlayer(this.getPlayerB());piece03.setPlayer(this.getPlayerB());piece04.setPlayer(this.getPlayerB());piece05.setPlayer(this.getPlayerB());piece06.setPlayer(this.getPlayerB());

    }

    public void BringNewPiece(String s,Player player,Cell cell){
        for (int i = 0; i < player.getPieces().size(); i++) {
            if(s.equals(player.getPieces().get(i).toString())){

                if(cell.getPiece()==null){

                    if(player.getColor().equals(Color.WHITE)){
                        if(player.getPieces().get(i) instanceof Pawn){

                            Piece piece=new Pawn(cell,Color.WHITE,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }
                        if(player.getPieces().get(i) instanceof Bishop){

                            Piece piece=new Bishop(cell,Color.WHITE,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }
                        if(player.getPieces().get(i) instanceof Lance){

                            Piece piece=new Lance(cell,Color.WHITE,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }
                        if(player.getPieces().get(i) instanceof SilverGeneral){

                            Piece piece=new SilverGeneral(cell,Color.WHITE,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }
                        if(player.getPieces().get(i) instanceof GoldGeneral){

                            Piece piece=new GoldGeneral(cell,Color.WHITE,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }

                    }
                    if(player.getColor().equals(Color.BLACK)){
                        if(player.getPieces().get(i) instanceof Pawn){

                            Piece piece=new Pawn(cell,Color.BLACK,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }
                        if(player.getPieces().get(i) instanceof Bishop){

                            Piece piece=new Bishop(cell,Color.BLACK,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }
                        if(player.getPieces().get(i) instanceof Lance){

                            Piece piece=new Lance(cell,Color.BLACK,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }
                        if(player.getPieces().get(i) instanceof SilverGeneral){

                            Piece piece=new SilverGeneral(cell,Color.BLACK,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }
                        if(player.getPieces().get(i) instanceof GoldGeneral){

                            Piece piece=new GoldGeneral(cell,Color.BLACK,this);
                            this.getPieces()[cell.getX()][cell.getY()]=piece;
                            cell.setPiece(piece);
                            piece.setPlayer(player);
                        }

                    }

                    player.getPieces().remove(i);
                    Player.turn++;

                }
            }
        }

    }

    public void Move(Piece piece,Cell a,Cell b){

        if(b.getX() >= 0 && b.getY() >= 0 && b.getX() <= 4 && b.getY() <= 4&&a.getX() >= 0 && a.getY() >= 0 && a.getX() <= 4 && a.getY() <= 4&&piece!=null&&piece.getPlayer().Player_turn()){


            if(piece.getCurrentCell().getX()==a.getX()&&piece.getCurrentCell().getY()==a.getY()){

                if(piece.is_Valid_move(b)){

                    if(piece!=null&&piece.getColor().equals(Color.WHITE)){
                        if((b.getX()==3)||(b.getX()==4)){
                            piece.setUpgrade(true);
                        }
                    }
                    if(piece!=null&&piece.getColor().equals(Color.BLACK)){
                        if((b.getX()==0)||(b.getX()==1)){
                            piece.setUpgrade(true);
                        }
                    }


                    if(b.getPiece()!=null){
                        if(b.getPiece().getColor().equals(Color.WHITE)){

                            playerB.getPieces().add(b.getPiece());

                        }
                        if(b.getPiece().getColor().equals(Color.BLACK)){
                            playerW.getPieces().add(b.getPiece());

                        }
                    }
                    if(b.getPiece()!=null&&b.getPiece() instanceof King){

                        if(piece.getColor().equals(Color.WHITE)){
                            playerW.setKing_dead(true);
                        }
                        if(piece.getColor().equals(Color.BLACK)){
                            playerB.setKing_dead(true);
                        }
                    }
                    this.getPieces()[b.getX()][b.getY()]=piece;
                    piece.setCurrentCell(b);
                    b.setPiece(piece);
                    this.getPieces()[a.getX()][a.getY()]=null;
                    a.setPiece(null);
Player.turn++;

                }
            }
            playerB.Change();
            playerW.Change();

        }

    }

    @Override
    public String toString() {
        String s="";
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                String p=(this.getPieces()[i][j]+"");
                if(this.getPieces()[i][j]==null){p="-";}

               s= s+(p);


            }

        }

        return s;
    }
}
