package W;

import java.awt.*;

public class Lance extends Piece{


    public Lance(Cell currentCell, Color color,Board board) {

        super(currentCell,color,board);
    }

    public boolean empty(Cell cell){

        boolean empty=true;
        if(cell.getY()>this.getCurrentCell().getY()){
            int yy=this.getCurrentCell().getY()+1;
            int y=cell.getY();



            for (int i =yy ; i <y ; i++) {


                if(getBoard().getPieces()[cell.getX()][i] !=null){
                    empty=false;
                    break;
                }
            }

        }
        if(cell.getY()<this.getCurrentCell().getY()){
            int y=this.getCurrentCell().getY();
            int yy=cell.getY()+1;


            for (int i =yy ; i <y ; i++) {

                if(getBoard().getPieces()[cell.getX()][i]!=null){
                    empty=false;
                    break;
                }
            }
            return empty;
        }
        if(cell.getX()>this.getCurrentCell().getX()){
            int yy=this.getCurrentCell().getX()+1;
            int y=cell.getX();


            for (int i =yy ; i <y ; i++) {

                Cell cell1=new Cell(i,this.getCurrentCell().getY(),getBoard());
                if(cell1.getPiece()!=null){

                    empty=false;
                    return false;

                }
            }
            return empty;
        }
        if(cell.getX()<this.getCurrentCell().getX()){
            int y=this.getCurrentCell().getX();
            int yy=cell.getX()+1;



            for (int i =yy ; i <y ; i++) {

Cell cell1=new Cell(i,cell.getY(),getBoard());
                if(cell1.getPiece()!=null){
                    empty=false;
                    break;
                }
            }
            return empty;
        }
        return empty;
    }

    public boolean is_Valid_move(Cell cell){

        if(empty(cell)==false)
        {
             ;return false;}
        else {

            if (this.isUpgrade() == false) {
                if (this.getColor().equals(Color.WHITE)) {


                    if (cell.getPiece() == null && cell.getY() == this.getCurrentCell().getY() && this.getCurrentCell().getX() < cell.getX()) {
                        return true;
                    }
                    if (cell.getPiece() != null && !cell.getPiece().getColor().equals(this.getColor()) && cell.getY() == this.getCurrentCell().getY() && this.getCurrentCell().getX() < cell.getX()) {

                        return true;
                    }
                }
                else {
                    if (cell.getPiece() == null && cell.getY() == this.getCurrentCell().getY() && this.getCurrentCell().getX() > cell.getX()) {
                        return true;
                    }
                    if (cell.getPiece() != null && !cell.getPiece().getColor().equals(this.getColor()) && cell.getY() == this.getCurrentCell().getY() && this.getCurrentCell().getX() > cell.getX()) {

                        return true;
                    }
                }

            }
            if (this.isUpgrade() == true) {

                if (cell.getPiece() == null && cell.getY() == this.getCurrentCell().getY() && (this.getCurrentCell().getX() < cell.getX() || this.getCurrentCell().getX() > cell.getX())) {
                    return true;
                }
                if (cell.getPiece() != null && !cell.getPiece().getColor().equals(this.getColor()) && cell.getY() == this.getCurrentCell().getY() && (this.getCurrentCell().getX() < cell.getX() || this.getCurrentCell().getX() > cell.getX())) {

                    return true;
                }
                if (cell.getPiece() == null && cell.getX() == this.getCurrentCell().getX() && (this.getCurrentCell().getY() < cell.getY() || this.getCurrentCell().getY() > cell.getY())) {
                    return true;
                }
                if (cell.getPiece() != null && !cell.getPiece().getColor().equals(this.getColor()) && cell.getX() == this.getCurrentCell().getX() && (this.getCurrentCell().getY() < cell.getY() || this.getCurrentCell().getY() > cell.getY())) {

                    return true;
                }

            }
            return false;
        }
    }

    @Override
    public String toString() {
        if(this.getColor().equals(Color.WHITE)){
            return "L";}
        else return "l";
    }
}
