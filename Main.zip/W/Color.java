package W;

public enum Color {
    WHITE,
    BLACK

}
