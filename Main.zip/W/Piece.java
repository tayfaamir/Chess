package W;

public class Piece {

    private Color color;

    private boolean upgrade;

    private Cell currentCell;

    private Player player;

    private Board board;

    public Piece(Cell currentCell,Color color,Board board) {

        this.color = color;
        this.currentCell = currentCell;
        this.upgrade=false;
        this.board=board;

        board.getPieces()[currentCell.getX()][currentCell.getY()]=this;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Cell getCurrentCell() {
        return currentCell;
    }

    public void setCurrentCell(Cell currentCell) {
        this.currentCell = currentCell;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public boolean isUpgrade() {
        return upgrade;
    }

    public void setUpgrade(boolean upgrade) {
        this.upgrade = upgrade;
    }
    public boolean is_Valid_move(Cell cell) {
        return false;
    }

    public Board getBoard() {
        return board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    @Override
    public String toString() {
        return  "";
    }
}
