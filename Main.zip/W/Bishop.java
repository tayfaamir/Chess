package W;
import java.awt.*;


public class Bishop extends W.Piece {
    public Bishop(W.Cell currentCell, Color color, W.Board board) {
        super(currentCell, color,board);
    }
    public boolean is_empty(W.Cell cell){




            if(cell.getX()>this.getCurrentCell().getX()){
                if(this.getCurrentCell().getY()>cell.getY()){
                    int xx=this.getCurrentCell().getX();
                    int yy=this.getCurrentCell().getY();
                    xx=xx+1;
                    yy=yy-1;
                    for (int i = xx; i < cell.getX() ; i++) {


                        if (getBoard().getPieces()[i][yy]!= null) {

                           return false;

                        }
                        yy=yy-1;
                    }
                }
                if(this.getCurrentCell().getY()<cell.getY()){
                    int xx=this.getCurrentCell().getX();
                    int yy=this.getCurrentCell().getY();
                    xx=xx+1;
                    yy=yy+1;
                    for (int i = yy; i < cell.getY() ; i++) {



                        if (getBoard().getPieces()[xx][i]!= null) {

                           return false;

                        }
                        xx++;
                    }

                }
            }

        if(cell.getX()<this.getCurrentCell().getX()){
            if(this.getCurrentCell().getY()>cell.getY()){
                int xx=cell.getX();
                int yy=this.getCurrentCell().getY();
                xx=xx+1;
                yy=yy-1;
                for (int i = xx; i < this.getCurrentCell().getX() ; i++) {


                    if (getBoard().getPieces()[i][yy]!= null) {

                        return false;

                    }
                    yy=yy-1;
                }
            }

            if(this.getCurrentCell().getY()<cell.getY()){
                int xx=this.getCurrentCell().getX();
                int yy=this.getCurrentCell().getY();
                xx=xx-1;
                yy=yy+1;
                for (int i = yy; i < cell.getY() ; i++) {



                    if (getBoard().getPieces()[xx][i]!= null) {

                        return false;

                    }
                    xx--;
                }

            }
        }



        return true;


    }

    public boolean is_Valid_move(W.Cell cell) {

        if(is_empty(cell)==false){

            return false;
        }

        else {
            if (this.isUpgrade() == false) {
                if (this.getColor().equals(Color.WHITE)) {
                    if (cell.getPiece() == null && (Math.abs(this.getCurrentCell().getX() - cell.getX()) == Math.abs(cell.getY() - this.getCurrentCell().getY())) && cell.getX() > this.getCurrentCell().getX()) {
                        return true;
                    }
                    if (cell.getPiece() != null && !cell.getPiece().getColor().equals(this.getColor()) && (Math.abs(this.getCurrentCell().getX() - cell.getX()) == Math.abs(cell.getY() - this.getCurrentCell().getY())) && cell.getX() > this.getCurrentCell().getX()) {
                        return true;
                    }
                }
                if (this.getColor().equals(Color.BLACK)) {
                    if (cell.getPiece() == null && (Math.abs(this.getCurrentCell().getX() - cell.getX()) == Math.abs(cell.getY() - this.getCurrentCell().getY())) && cell.getX() < this.getCurrentCell().getX()) {

                        return true;
                    }
                    if ( !cell.getPiece().getColor().equals(this.getColor()) && (Math.abs(this.getCurrentCell().getX() - cell.getX()) == Math.abs(cell.getY() - this.getCurrentCell().getY())) && cell.getX() < this.getCurrentCell().getX()) {

                        return true;
                    }
                }
                }

            }
            if (this.isUpgrade() == true) {
                if (cell.getPiece() == null && ((Math.abs(this.getCurrentCell().getX() - cell.getX()) == Math.abs(cell.getY() - this.getCurrentCell().getY())) || (this.getCurrentCell().getX() + 1 == cell.getX() || this.getCurrentCell().getX() - 1 == cell.getX())||(this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY()))) {
                    return true;
                }
                if (cell.getPiece() != null && !cell.getPiece().getColor().equals(this.getColor()) && ((Math.abs(this.getCurrentCell().getX() - cell.getX()) == Math.abs(cell.getY() - this.getCurrentCell().getY())) || (this.getCurrentCell().getX() + 1 == cell.getX() || this.getCurrentCell().getX() - 1 == cell.getX())||(this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY()))) {
                    return true;
                }

            }

            return false;
        }



    @Override
    public String toString() {
        if(this.getColor().equals(Color.WHITE)){
            return "B";}
        else return "b";
    }
}
