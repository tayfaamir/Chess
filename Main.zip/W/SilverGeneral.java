package W;

import java.awt.*;

public class SilverGeneral extends Piece {


    public SilverGeneral(Cell currentCell, Color color, Board board) {
        super(currentCell, color, board);
    }

    public boolean is_Valid_move(Cell cell) {
        if (this.isUpgrade() == false) {
            if (cell.getPiece() == null) {
                if (this.getColor().equals(Color.WHITE)) {
                    if (cell.getX() == this.getCurrentCell().getX() + 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                        return true;
                    }
                    if (cell.getX() == this.getCurrentCell().getX() - 1 && (this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                        return true;
                    }

                    return false;
                }
                if (this.getColor().equals(Color.BLACK)) {
                    if (cell.getX() == this.getCurrentCell().getX() - 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                        return true;
                    }
                    if (cell.getX() == this.getCurrentCell().getX() + 1 && (this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                        return true;
                    }

                    return false;
                }
                return false;
            }
            else {
                if (!cell.getPiece().getColor().equals(this.getColor())) {
                    if (this.getColor().equals(Color.WHITE)) {
                        if (cell.getX() == this.getCurrentCell().getX() + 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                            return true;
                        }
                        if (cell.getX() == this.getCurrentCell().getX() - 1 && (this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                            return true;
                        }

                        return false;
                    }
                    if (this.getColor().equals(Color.BLACK)) {
                        if (cell.getX() == this.getCurrentCell().getX() - 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                            return true;
                        }
                        if (cell.getX() == this.getCurrentCell().getX() + 1 && (this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                            return true;
                        }

                        return false;
                    }
                }
                return false;
            }
        }
        else {
            if (cell.getPiece() == null) {
                if (cell.getX() == this.getCurrentCell().getX() + 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }
                if (cell.getX() == this.getCurrentCell().getX() && (this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }
                if (cell.getX() == this.getCurrentCell().getX() - 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }

                if (cell.getX() - this.getCurrentCell().getX() == 2 && cell.getY() == this.getCurrentCell().getY()) {

                    if (getBoard().getPieces()[this.getCurrentCell().getX() + 1][this.getCurrentCell().getY()] == null) {
                        return true;
                    }

                }

                if (this.getCurrentCell().getX() - cell.getX() == 2 && cell.getY() == this.getCurrentCell().getY()) {

                    if (getBoard().getPieces()[cell.getX() + 1][this.getCurrentCell().getY()] == null) {
                        return true;
                    }

                }

                if (cell.getY() - this.getCurrentCell().getY() == 2 && cell.getX() == this.getCurrentCell().getX()) {

                    if (getBoard().getPieces()[this.getCurrentCell().getX()][this.getCurrentCell().getY() + 1] == null) {
                        return true;
                    }

                }

                if (this.getCurrentCell().getY() - cell.getY() == 2 && cell.getX() == this.getCurrentCell().getX()) {

                    if (getBoard().getPieces()[cell.getX() + 1][cell.getY() + 1] == null) {
                        return true;
                    }

                }

                if (this.getCurrentCell().getY() - cell.getY() == 2 && cell.getX() - this.getCurrentCell().getX() == 2) {

                    if (getBoard().getPieces()[this.getCurrentCell().getX() + 1][cell.getY() + 1] == null) {
                        return true;
                    }

                }

                if (this.getCurrentCell().getY() - cell.getY() == 2 && this.getCurrentCell().getX() - cell.getX() == 2) {

                    if (getBoard().getPieces()[cell.getX() + 1][cell.getY() + 1] == null) {
                        return true;
                    }

                }

                if (cell.getY() - this.getCurrentCell().getY() == 2 && cell.getX() - this.getCurrentCell().getX() == 2) {

                    if (getBoard().getPieces()[this.getCurrentCell().getX() + 1][this.getCurrentCell().getY() + 1] == null) {
                        return true;
                    }

                }

                if (cell.getY() - this.getCurrentCell().getY() == 2 && this.getCurrentCell().getX() - cell.getX() == 2) {

                    if (getBoard().getPieces()[cell.getX() + 1][this.getCurrentCell().getY() + 1] == null) {
                        return true;
                    }

                }

                return false;
            } else {
                if (cell.getX() == this.getCurrentCell().getX() + 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }
                if (cell.getX() == this.getCurrentCell().getX() && (this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }
                if (cell.getX() == this.getCurrentCell().getX() - 1 && (this.getCurrentCell().getY() == cell.getY() || this.getCurrentCell().getY() + 1 == cell.getY() || this.getCurrentCell().getY() - 1 == cell.getY())) {
                    return true;
                }

                if (cell.getX() - this.getCurrentCell().getX() == 2 && cell.getY() == this.getCurrentCell().getY()) {

                    if (getBoard().getPieces()[this.getCurrentCell().getX() + 1][this.getCurrentCell().getY()] == null) {
                        return true;
                    }

                }

                if (this.getCurrentCell().getX() - cell.getX() == 2 && cell.getY() == this.getCurrentCell().getY()) {

                    if (getBoard().getPieces()[cell.getX() + 1][this.getCurrentCell().getY()] == null) {
                        return true;
                    }

                }

                if (cell.getY() - this.getCurrentCell().getY() == 2 && cell.getX() == this.getCurrentCell().getX()) {

                    if (getBoard().getPieces()[this.getCurrentCell().getX()][this.getCurrentCell().getY() + 1] == null) {
                        return true;
                    }

                }

                if (this.getCurrentCell().getY() - cell.getY() == 2 && cell.getX() == this.getCurrentCell().getX()) {

                    if (getBoard().getPieces()[cell.getX()][cell.getY() + 1] == null) {
                        return true;
                    }

                }

                if (this.getCurrentCell().getY() - cell.getY() == 2 && cell.getX() - this.getCurrentCell().getX() == 2) {

                    if (getBoard().getPieces()[this.getCurrentCell().getX() + 1][cell.getY() + 1] == null) {
                        return true;
                    }

                }

                if (this.getCurrentCell().getY() - cell.getY() == 2 && this.getCurrentCell().getX() - cell.getX() == 2) {

                    if (getBoard().getPieces()[cell.getX() + 1][cell.getY() + 1] == null) {
                        return true;
                    }

                }

                if (cell.getY() - this.getCurrentCell().getY() == 2 && cell.getX() - this.getCurrentCell().getX() == 2) {

                    if (getBoard().getPieces()[this.getCurrentCell().getX() + 1][this.getCurrentCell().getY() + 1] == null) {
                        return true;
                    }

                }

                if (cell.getY() - this.getCurrentCell().getY() == 2 && this.getCurrentCell().getX() - cell.getX() == 2) {

                    if (getBoard().getPieces()[cell.getX() + 1][this.getCurrentCell().getY() + 1] == null) {
                        return true;
                    }

                }

                return false;
            }

        }

    }


        @Override
        public String toString () {
            if (this.getColor().equals(Color.WHITE)) {
                return "S";
            } else return "s";
        }
    }
