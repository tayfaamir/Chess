package gui;

import W.Board;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.LinkedList;

public class Game_state extends JPanel {

    private LinkedList<JButton> buttons=new LinkedList<>();



    private JFrame jFrame;

    public Game_state() {
        this.jFrame=new JFrame("game");
        this.jFrame.setVisible(true);
        this.jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Dimension size = Toolkit. getDefaultToolkit(). getScreenSize();
        this.jFrame.setSize(size.width+500,size.height+500);
        jFrame.setResizable(false);
        GridLayout gridLayout=new GridLayout(6,7);
        this.jFrame.setLayout(gridLayout);
        JButton jButton1=new JButton();JButton jButton3=new JButton("3");JButton jButton9=new JButton("9");JButton jButton13=new JButton("13");
        JButton jButton2=new JButton("2");JButton jButton4=new JButton("4");JButton jButton10=new JButton("10");JButton jButton14=new JButton();
        JButton jButton5=new JButton("5");JButton jButton7=new JButton();JButton jButton11=new JButton("11");JButton jButton15=new JButton();
        JButton jButton6=new JButton("6");JButton jButton8=new JButton();JButton jButton12=new JButton("12");JButton jButton16=new JButton("16");
        JButton jButton17=new JButton("17");JButton jButton18=new JButton("18"); JButton jButton19=new JButton("19");;JButton jButton20=new JButton("20");
        JButton jButton21=new JButton();JButton jButton22=new JButton();JButton jButton23= new JButton("23");JButton jButton24=new JButton("24");
        JButton jButton25=new JButton("25");JButton jButton26=new JButton("26");JButton jButton27=new JButton("27");
        JButton jButton28=new JButton();JButton jButton29=new JButton();JButton jButton30=new JButton("30");
        JButton jButton31=new JButton("31");JButton jButton32=new JButton("32");JButton jButton33=new JButton("33");
        JButton jButton34=new JButton("34");JButton jButton35=new JButton();JButton jButton36=new JButton("B pieces");
        JButton jButton37=new JButton("1");JButton jButton38=new JButton("2");JButton jButton39=new JButton("3");
        JButton jButton40=new JButton("4");JButton jButton41=new JButton("5");JButton jButton42=new JButton("W pieces");
        buttons.add(jButton1);buttons.add(jButton2);buttons.add(jButton3);buttons.add(jButton4);buttons.add(jButton5);buttons.add(jButton6);
        buttons.add(jButton7);buttons.add(jButton8);buttons.add(jButton9);buttons.add(jButton10);buttons.add(jButton11);buttons.add(jButton12);
        buttons.add(jButton13);buttons.add(jButton14);buttons.add(jButton15);buttons.add(jButton16);buttons.add(jButton17);buttons.add(jButton18);
        buttons.add(jButton19);buttons.add(jButton20);buttons.add(jButton21);buttons.add(jButton22);buttons.add(jButton23);buttons.add(jButton24);
        buttons.add(jButton25);buttons.add(jButton26);buttons.add(jButton27);buttons.add(jButton28);buttons.add(jButton29);buttons.add(jButton30);
        buttons.add(jButton31);buttons.add(jButton32);buttons.add(jButton33);buttons.add(jButton34);buttons.add(jButton35);buttons.add(jButton36);
        buttons.add(jButton37);buttons.add(jButton38);buttons.add(jButton39);buttons.add(jButton40);buttons.add(jButton41);buttons.add(jButton42);
        this.jFrame.add(jButton1);this.jFrame.add(jButton2);this.jFrame.add(jButton3);this.jFrame.add(jButton4);this.jFrame.add(jButton5);
        this.jFrame.add(jButton6);this.jFrame.add(jButton7);this.jFrame.add(jButton8);this.jFrame.add(jButton9);this.jFrame.add(jButton10);
        this.jFrame.add(jButton11);this.jFrame.add(jButton12);this.jFrame.add(jButton13);this.jFrame.add(jButton14);this.jFrame.add(jButton15);
        this.jFrame.add(jButton16);this.jFrame.add(jButton17);this.jFrame.add(jButton18);this.jFrame.add(jButton19);this.jFrame.add(jButton20);
        this.jFrame.add(jButton21);this.jFrame.add(jButton22);this.jFrame.add(jButton23);this.jFrame.add(jButton24);this.jFrame.add(jButton25);
        this.jFrame.add(jButton26);this.jFrame.add(jButton27);this.jFrame.add(jButton28);this.jFrame.add(jButton29);this.jFrame.add(jButton30);
        this.jFrame.add(jButton31);this.jFrame.add(jButton32);this.jFrame.add(jButton33);this.jFrame.add(jButton34);this.jFrame.add(jButton35);
        this.jFrame.add(jButton36);this.jFrame.add(jButton37);this.jFrame.add(jButton38);this.jFrame.add(jButton39);this.jFrame.add(jButton40);
        this.jFrame.add(jButton41);this.jFrame.add(jButton42);

        jButton37.setName("10000");jButton38.setName("20000");jButton39.setName("30000");jButton40.setName("40000");jButton41.setName("50000");jButton42.setName("60000");
        jButton35.setName("5155");jButton36.setName("70000");
        jButton30.setName("11");jButton31.setName("21");jButton32.setName("31");jButton33.setName("41");jButton34.setName("51");
        jButton28.setName("5154");jButton29.setName("5165");
        jButton23.setName("12");jButton24.setName("22");jButton25.setName("32");jButton26.setName("42");jButton27.setName("52");

        jButton21.setName("5153");jButton22.setName("5164");jButton14.setName("5152");jButton15.setName("5163");

        jButton7.setName("5151") ;jButton8.setName("5162") ;jButton1.setName("5161");

        jButton16.setName("13");jButton17.setName("23");jButton18.setName("33");jButton19.setName("43");jButton20.setName("53");
        jButton9.setName("14");jButton10.setName("24");jButton11.setName("34");jButton12.setName("44");jButton13.setName("54");
        jButton2.setName("15");jButton3.setName("25");jButton4.setName("35");jButton5.setName("45");jButton6.setName("55");



        for (int i = 0; i < buttons.size(); i++) {

            if(Integer.parseInt(buttons.get(i).getName())<100){
                buttons.get(i).setBackground(new Color(255,160,122));
            }
            else {
                ;buttons.get(i).setBackground(new Color(240,230,140));}

        }


    }

    public JFrame getjFrame() {
        return jFrame;
    }

    public void setjFrame(JFrame jFrame) {
        this.jFrame = jFrame;
    }

    public LinkedList<JButton> getButtons() {
        return buttons;
    }

    public void setButtons(LinkedList<JButton> buttons) {
        this.buttons = buttons;
    }

    public JButton finder(int x , int y){
        for (int i = 0; i < this.getButtons().size(); i++) {

            if(((y+1)+""+(x+1)).equals(this.buttons.get(i).getName())){

                return this.buttons.get(i);
            }


        }

        return null;
    }


    public String setSimple(JButton s){

        String w=s.getName();
        int a=Integer.parseInt(w.charAt(0)+"")-1;
        int b=Integer.parseInt(w.charAt(1)+"")-1;
        return b+""+a;
    }

    public JButton findBtn(int a,int b){

        for (int i = 0; i <buttons.size() ; i++) {
            if(buttons.get(i).getName().equals((b+1)+""+(a+1))){
                return buttons.get(i);
            }

        }
        return null;
    }


}
